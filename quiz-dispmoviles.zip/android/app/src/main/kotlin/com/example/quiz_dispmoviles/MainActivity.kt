package com.example.quiz_dispmoviles

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
